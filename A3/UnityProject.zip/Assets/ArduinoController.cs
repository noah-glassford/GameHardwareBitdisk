using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArduinoController : MonoBehaviour
{
    // Start is called before the first frame update
    public bool Toggle;
    // Update is called once per frame
    void Update()
    {
       transform.Translate(new Vector3(Input.GetAxis("Vertical"), 
       Input.GetAxis("Horizontal"), 0) * Time.deltaTime);

       if (Input.GetButtonUp("Fire1") && Toggle == false)
       {
            Toggle = true;
            gameObject.GetComponent<MeshRenderer>().material.color = Color.blue;

       }
        else if (Input.GetButtonUp("Fire1") && Toggle == true)
       {
            Toggle = false;
            gameObject.GetComponent<MeshRenderer>().material.color = Color.red;

       }
    }
}
